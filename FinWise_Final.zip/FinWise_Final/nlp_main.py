import os
import json
from MultiModel.NLP.src.file_loader import load_article
from MultiModel.NLP.src.sentence_splitter import split_sentences
from MultiModel.NLP.src.term_extractor import extract_terms
from MultiModel.NLP.src.sentence_filter import filter_sentences_by_term_count
from MultiModel.NLP.src.relation_extractor import extract_verbs, load_custom_verbs, cleanup
from collections import Counter


def load_json_list(json_path, key):
    """
    Load a list from a JSON file by a specific key.
    """
    try:
        with open(json_path, "r", encoding="utf-8") as file:
            data = json.load(file)
        return data.get(key, [])
    except FileNotFoundError:
        print(f"File not found: {json_path}")
        return []
    except json.JSONDecodeError:
        print(f"Invalid JSON format: {json_path}")
        return []


def process_file(file_path, financial_terms, not_verbs, yes_verbs):
    """
    Process a single text file: extract sentences, terms, and relationships.
    """
    document = load_article(file_path)
    sentences = split_sentences(document)
    sentence_with_terms = [
        (sentence, extract_terms(sentence, financial_terms)) for sentence in sentences
    ]
    filtered_sentences = filter_sentences_by_term_count(sentence_with_terms, min_count=2, max_count=2)

    results = []

    for sentence, terms in filtered_sentences:
        verbs = extract_verbs(sentence, not_verbs, yes_verbs)
        top_verbs = [verb for verb, _ in Counter(verbs).most_common(2)]
        results.append({
            "article": os.path.basename(file_path),
            "sentence": sentence,
            "terms": terms,
            "verbs": top_verbs
        })

    return results


def save_as_json(output_path, data):
    """
    Save data as JSON to the specified output path.
    """
    with open(output_path, "w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=4)
    print(f"Results saved to {output_path}")


def main():
    """
    Main function to orchestrate the NLP pipeline.
    """
    try:
        # Paths to JSON files
        json_dir = "./MultiModel/NLP/datasets/json/"
        yes_verbs_path = os.path.join(json_dir, "yes_verb.json")
        financial_terms_path = os.path.join(json_dir, "financial_terms.json")
        not_verbs_path = os.path.join(json_dir, "not_verb.json")

        # Load JSON data
        financial_terms = load_json_list(financial_terms_path, "terms")
        not_verbs = load_json_list(not_verbs_path, "not_verbs")
        yes_verbs = load_json_list(yes_verbs_path, "yes_verbs")
        
        # Load custom verbs into KoalaNLP dictionary
        load_custom_verbs(yes_verbs_path)

        # Process articles
        data_dir = "./MultiModel/NLP/datasets/article/"
        article_files = [os.path.join(data_dir, f) for f in os.listdir(data_dir) if f.endswith(".txt")]

        if not article_files:
            print("No files to analyze.")
            return

        all_extracted_keywords = set()  # To store all unique financial terms across articles

        for file_path in article_files:
            print(f"\n=== Processing {os.path.basename(file_path)} ===")
            file_results = process_file(file_path, financial_terms, not_verbs, yes_verbs)

            # Collect terms and verbs from the results
            all_terms = Counter()
            nodes = []
            edges = []
            edge_id = 1

            for result in file_results:
                terms = result["terms"]
                verbs = result["verbs"]

                # Collect all unique terms
                all_extracted_keywords.update(terms)

                # Count term frequencies
                all_terms.update(terms)

                # Create edges
                edges.append({
                    "id": f"edge{edge_id}",
                    "nodes": terms,
                    "description": ", ".join(verbs)
                })
                edge_id += 1

            # Create nodes with importance based on frequency
            for term, freq in all_terms.items():
                importance = round(10 ** -freq, 10)  # Convert frequency to a small decimal
                nodes.append({
                    "id": term,
                    "importance": importance
                })

            # Save results for each article
            output_path = f"./MultiModel/NLP/results/{os.path.splitext(os.path.basename(file_path))[0]}_hypergraph_data.json"
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            save_as_json(output_path, {"nodes": nodes, "edges": edges})

        # Save extracted keywords to a single file
        extracted_keywords_path = "./MultiModel/NLP/results/extracted_keywords.json"
        save_as_json(extracted_keywords_path, sorted(list(all_extracted_keywords)))

    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        # Cleanup JVM
        cleanup()
        print("KoalaNLP JVM shutdown complete.")


if __name__ == "__main__":
    main()
