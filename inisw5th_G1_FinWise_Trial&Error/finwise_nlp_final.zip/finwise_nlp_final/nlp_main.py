import os
import json
from MultiModel.NLP.src.file_processor import (
    load_article, split_sentences, extract_verbs_and_nouns, cleanup
)
from MultiModel.NLP.src.important import (
    filter_top_5_verbs_relationships_with_limited_pairs
)

def process_file(file_path, output_path):
    """
    단일 텍스트 파일을 처리: 문장, 동사, 키워드를 추출.
    중요한 관계만 JSON 형식으로 저장.
    """
    document = load_article(file_path)
    sentences = split_sentences(document)

    results = []

    for sentence in sentences:
        verbs, nouns = extract_verbs_and_nouns(sentence)
        if len(nouns) < 2:
            continue  # 명사가 2개 미만인 문장은 생략

        # 길이가 2 이상인 동사만 필터링
        filtered_verbs = [verb for verb in verbs if len(verb) >= 2]

        if not filtered_verbs:
            continue  # 유효한 동사가 없으면 생략

        # 명사 쌍 생성
        noun_pairs = [(nouns[i], nouns[j]) for i in range(len(nouns)) for j in range(i + 1, len(nouns))]

        for verb in filtered_verbs:
            for noun1, noun2 in noun_pairs:
                # noun1과 noun2가 동일하지 않은 경우만 추가
                if noun1 != noun2:
                    results.append({
                        "verb": verb,
                        "keywords": (noun1, noun2)  # "nouns"를 "keywords"로 변경
                    })

    # 중복된 결과 제거
    unique_results = remove_duplicates(results)

    # 파일 이름 추가
    file_name = os.path.basename(file_path)
    file_results = {file_name: unique_results}

    # 모든 관계를 임시 파일에 저장
    temp_file_path = "./temp_relationships.json"
    save_relationships_as_json(temp_file_path, file_results)  # 파일명 포함 결과 저장

    # 중요한 관계를 필터링하고 저장
    filter_top_5_verbs_relationships_with_limited_pairs(
        json_file_path=temp_file_path,
        output_file_path=output_path,
        top_n=5  # 상위 n개의 동사 기준으로 필터링
    )

    # 임시 파일 삭제
    if os.path.exists(temp_file_path):
        os.remove(temp_file_path)


def remove_duplicates(results):
    """
    결과에서 중복 항목 제거.
    """
    unique_results = []
    seen = set()

    for entry in results:
        # 동사와 정렬된 키워드를 사용하여 고유 키 생성
        key = (entry["verb"], tuple(sorted(entry["keywords"])))  # "nouns" -> "keywords"
        if key not in seen:
            seen.add(key)
            unique_results.append(entry)

    return unique_results


def save_relationships_as_json(file_path, relationships):
    """
    관계를 JSON 형식으로 저장.
    """
    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(relationships, file, ensure_ascii=False, indent=4)

    print(f"관계가 {file_path}에 저장되었습니다.")


def main():
    """
    NLP 파이프라인을 실행하는 메인 함수.
    """
    try:
        # 기사 처리
        data_dir = "./MultiModel/NLP/datasets/article/"
        article_files = [os.path.join(data_dir, f) for f in os.listdir(data_dir) if f.endswith(".txt")]

        if not article_files:
            print("분석할 파일이 없습니다.")
            return

        output_path = "./MultiModel/NLP/results/article_relations.json"
        final_output = {}

        for file_path in article_files:
            print(f"\n=== {os.path.basename(file_path)} 처리 중 ===")
            process_file(file_path, output_path)

    except Exception as e:
        print(f"오류가 발생했습니다: {e}")
    finally:
        # JVM 정리
        cleanup()
        print("KoalaNLP JVM 종료 완료.")


if __name__ == "__main__":
    main()
