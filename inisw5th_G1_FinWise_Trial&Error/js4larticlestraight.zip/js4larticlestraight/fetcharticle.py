from utils.fetch_content import fetch_content

def main():
    print("Welcome to Content Crawler!")
    url = input("Enter the URL to crawl: ").strip()

    try:
        # 크롤링 수행
        content = fetch_content(url)
        if content:
            print("\n--- Extracted Content ---\n")
            print(content)
        else:
            print("No content found with the specified criteria.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
