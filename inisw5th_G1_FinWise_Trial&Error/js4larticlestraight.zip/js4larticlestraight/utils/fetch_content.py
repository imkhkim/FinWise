import requests
from bs4 import BeautifulSoup

def fetch_content(url):
    try:
        # 웹페이지 요청
        response = requests.get(url)
        response.raise_for_status()  # HTTP 오류 발생 시 예외 발생

        # HTML 파싱
        soup = BeautifulSoup(response.text, 'html.parser')

        # 매일경제 URL 확인
        if "mk.co.kr" in url:
            return fetch_maeil_content(soup)
        # 한국경제 URL 확인
        elif "hankyung.com" in url:
            return fetch_hankyung_content(soup)
        else:
            return "Unsupported URL"

    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to fetch the URL: {e}")


def fetch_maeil_content(soup):
    """
    Fetches the content from 매일경제 articles (e.g., economy section).
    """
    content_element = soup.find('div', class_='news_cnt_detail_wrap')
    if content_element:
        return content_element.get_text(strip=True)  # 텍스트만 반환
    return "No content found on Maeil."


def fetch_hankyung_content(soup):
    """
    Fetches the content from 한국경제 articles.
    """
    # 한국경제에서 콘텐츠가 담겨 있는 부분을 찾음
    content_element = soup.find('div', class_='article-body', id='articletxt', itemprop='articleBody')
    if content_element:
        return content_element.get_text(strip=True)  # 텍스트만 반환
    return "No content found on Hankyung."
