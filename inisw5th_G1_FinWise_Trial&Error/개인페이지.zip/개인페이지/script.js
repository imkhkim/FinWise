const sidebar = document.getElementById("sidebar");
const openSidebarButton = document.getElementById("openSidebarButton");
const closeSidebarButton = document.getElementById("closeSidebarButton");

function toggleSidebar() {
    const isVisible = sidebar.classList.contains("visible");
    if (isVisible) {
        sidebar.classList.remove("visible");
        openSidebarButton.style.display = "block"; // 열기 버튼 표시
    } else {
        sidebar.classList.add("visible");
        openSidebarButton.style.display = "none"; // 열기 버튼 숨기기
    }
}
