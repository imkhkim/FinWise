from konlpy.tag import Mecab
from dataclasses import dataclass
from typing import List, Optional, Dict, Tuple
import re

@dataclass
class Eojeol:
    """어절 정보"""
    text: str                # 원문 텍스트
    morphs: List[Tuple[str, str]]  # 형태소 분석 결과
    base_form: str          # 기본형
    pos: str                # 주요 품사
    particle: Optional[str] = None  # 조사

@dataclass
class Clause:
    """절 정보"""
    eojeols: List[Eojeol]
    type: str = 'MAIN'      # MAIN, COORDINATE, QUOTE
    level: int = 0          # 중첩 레벨

@dataclass
class SVOResult:
    """분석 결과"""
    subject: Optional[str]
    verb: Optional[str]
    object: Optional[str]
    clause_type: str
    confidence: float

class KoreanSVOAnalyzer:
    def __init__(self):
        self.mecab = Mecab()
        
        # 문법 요소 정의
        self.PARTICLES = {
            'subject': ['은', '는', '이', '가'],
            'object': ['을', '를']
        }
        
        self.ENDINGS = {
            'coordinate': ['하고', '하며', '면서'],
            'quote': ['다고', '라고', '냐고'],
            'final': ['했다', '된다', '했습니다']
        }
        
        # 복합 명사 사전
        self.COMPOUND_NOUNS = {
            ('밸류업', '계획'),
            ('연말', '자본', '비율'),
            ('자본', '비율'),
            ('안정적', '수준')
        }
        
        # 용언 기본형 매핑
        self.VERB_BASE_FORMS = {
            '이행하고': '이행하다',
            '관리하겠다고': '관리하다',
            '설명했다': '설명하다',
            '흔들림': '흔들리다'
        }

    def _analyze_eojeol(self, text: str) -> Eojeol:
        """어절 분석"""
        morphs = self.mecab.pos(text)
        
        # 기본형과 품사 결정
        base_form = text
        pos = 'UNKNOWN'
        particle = None
        
        # 조사 확인
        if len(morphs) > 1 and morphs[-1][1].startswith('J'):
            particle = morphs[-1][0]
            base_form = ''.join(m[0] for m in morphs[:-1])
        
        # 품사 결정
        if any(m[1].startswith('V') or m[1].startswith('XSV') for m in morphs):
            pos = 'VERB'
            # 용언 기본형 복원
            if text in self.VERB_BASE_FORMS:
                base_form = self.VERB_BASE_FORMS[text]
        elif any(m[1].startswith('N') for m in morphs):
            pos = 'NOUN'
        
        return Eojeol(
            text=text,
            morphs=morphs,
            base_form=base_form,
            pos=pos,
            particle=particle
        )

    def _split_into_clauses(self, eojeols: List[Eojeol]) -> List[Clause]:
        """어절 목록을 절로 분리"""
        clauses = []
        current_clause = []
        
        for eojeol in eojeols:
            current_clause.append(eojeol)
            
            if eojeol.pos == 'VERB':
                # 절 종결 여부 확인
                for ending_type, patterns in self.ENDINGS.items():
                    if any(eojeol.text.endswith(p) for p in patterns):
                        clauses.append(Clause(
                            eojeols=current_clause.copy(),
                            type=ending_type.upper()
                        ))
                        current_clause = []
                        break
        
        if current_clause:
            clauses.append(Clause(eojeols=current_clause))
        
        return self._determine_clause_hierarchy(clauses)

    def _determine_clause_hierarchy(self, clauses: List[Clause]) -> List[Clause]:
        """절 간의 계층 구조 결정"""
        if not clauses:
            return clauses
            
        # 주절은 마지막 절
        clauses[-1].type = 'MAIN'
        clauses[-1].level = 0
        
        # 나머지 절들의 레벨 설정
        for i in range(len(clauses)-2, -1, -1):
            if clauses[i].type == 'QUOTE':
                clauses[i].level = clauses[i+1].level + 1
            else:
                clauses[i].level = clauses[i+1].level
        
        return clauses

    def _find_svo_in_clause(self, clause: Clause) -> SVOResult:
        """절에서 SVO 추출"""
        subject = None
        verb = None
        object = None
        
        # 복합 명사 처리를 위한 임시 저장
        noun_sequence = []
        
        for eojeol in clause.eojeols:
            if eojeol.pos == 'NOUN':
                noun_sequence.append(eojeol.base_form)
                
                # 주어 확인
                if eojeol.particle in self.PARTICLES['subject']:
                    subject = ' '.join(noun_sequence)
                    noun_sequence = []
                
                # 목적어 확인
                elif eojeol.particle in self.PARTICLES['object']:
                    object = ' '.join(noun_sequence)
                    noun_sequence = []
            
            # 용언 처리
            elif eojeol.pos == 'VERB':
                verb = eojeol.base_form
                noun_sequence = []
            else:
                noun_sequence = []
        
        # 신뢰도 계산
        confidence = 0.0
        if subject: confidence += 0.4
        if verb: confidence += 0.4
        if object: confidence += 0.2
        
        return SVOResult(
            subject=subject,
            verb=verb,
            object=object,
            clause_type=clause.type,
            confidence=confidence
        )

    def analyze(self, sentence: str) -> List[SVOResult]:
        """문장 분석 실행"""
        # 1. 어절 단위 분리 및 분석
        eojeols = [self._analyze_eojeol(e) for e in sentence.split()]
        
        # 2. 절 분리
        clauses = self._split_into_clauses(eojeols)
        
        # 3. 각 절에서 SVO 추출
        results = []
        last_subject = None
        
        for clause in clauses:
            svo = self._find_svo_in_clause(clause)
            
            # 생략된 주어 복원
            if not svo.subject and last_subject:
                svo.subject = last_subject
                svo.confidence += 0.1
            
            if svo.subject:
                last_subject = svo.subject
            
            if svo.confidence > 0:
                results.append(svo)
        
        return results

# 테스트
if __name__ == "__main__":
    analyzer = KoreanSVOAnalyzer()
    test_sentence = "문화계 명사들이 포함된 자칭 시민모임에서 광화문 현판을 개점토해 한글 편한으로 교체하자는 주장이 나왔다"
    
    results = analyzer.analyze(test_sentence)
    print("\n최종 분석 결과:")
    for idx, result in enumerate(results, 1):
        print(f"\n결과 {idx}:")
        print(f"절 유형: {result.clause_type}")
        print(f"주어: {result.subject}")
        print(f"서술어: {result.verb}")
        print(f"목적어: {result.object}")
        print(f"신뢰도: {result.confidence:.2f}")