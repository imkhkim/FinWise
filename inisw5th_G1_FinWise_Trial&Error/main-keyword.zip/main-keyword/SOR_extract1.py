from dataclasses import dataclass
from typing import List, Tuple, Set, Optional, Dict
from enum import Enum
from collections import defaultdict

class PosTag(Enum):
    # 체언
    NNG = "일반 명사"
    NNP = "고유 명사"
    NNB = "의존 명사"
    NR = "수사"
    NP = "대명사"
    
    # 용언
    VV = "동사"
    VA = "형용사"
    VX = "보조 용언"
    VCP = "긍정 지정사"
    VCN = "부정 지정사"
    
    # 수식언
    MM = "관형사"
    MAG = "일반 부사"
    MAJ = "접속 부사"
    
    # 독립언
    IC = "감탄사"
    
    # 관계언
    JKS = "주격 조사"
    JKC = "보격 조사"
    JKG = "관형격 조사"
    JKO = "목적격 조사"
    JKB = "부사격 조사"
    JKV = "호격 조사"
    JKQ = "인용격 조사"
    JX = "보조사"
    JC = "접속 조사"
    
    # 의존 형태
    EP = "선어말 어미"
    EF = "종결 어미"
    EC = "연결 어미"
    ETN = "명사형 전성 어미"
    ETM = "관형형 전성 어미"
    
    # 기호
    SF = "마침표,물음표,느낌표"
    SP = "쉼표"
    SS = "따옴표,괄호표"
    SE = "줄임표"
    SO = "붙임표"
    SW = "기타기호"
    
    # 접사/어근
    XPN = "체언 접두사"
    XSN = "명사 파생 접미사"
    XSV = "동사 파생 접미사"
    XSA = "형용사 파생 접미사"
    XR = "어근"
    
    # 한글 이외
    SL = "외국어"
    SH = "한자"
    SN = "숫자"
    
    # Komoran 특화
    NA = "분석불능범주"
    VSV = "용언추정범주"

@dataclass
class SVOResult:
    subject: str
    verb: str
    object: str
    modifiers: Dict[str, List[str]]
    confidence: float
    
    def __str__(self):
        result = [f"Subject: {self.subject}", f"Verb: {self.verb}", f"Object: {self.object}"]
        
        if self.modifiers:
            result.append("\nModifiers:")
            for mod_type, mods in self.modifiers.items():
                if mods:
                    result.append(f"  {mod_type}: {', '.join(mods)}")
        
        result.append(f"\nConfidence: {self.confidence:.2f}")
        return "\n".join(result)

@dataclass
class Clause:
    morphemes: List[Tuple[str, str]]
    start_idx: int
    end_idx: int
    is_complete: bool = True

class KoreanSVOExtractor:
    def __init__(self):
        # 품사 태그 그룹 정의
        self.NOUN_TAGS = {
            PosTag.NNG, PosTag.NNP, PosTag.NNB, 
            PosTag.NR, PosTag.NP
        }
        
        self.SUBJECT_PARTICLE_TAGS = {
            PosTag.JKS, PosTag.JX
        }
        
        self.OBJECT_PARTICLE_TAGS = {
            PosTag.JKO, PosTag.JKB
        }
        
        self.VERB_TAGS = {
            PosTag.VV, PosTag.VA, PosTag.VX, PosTag.XSV,
            PosTag.VSV  # Komoran 특화: 용언추정범주
        }
        
        self.NUMBER_TAGS = {
            PosTag.SN, PosTag.NR
        }
        
        self.CLAUSE_ENDING_TAGS = {
            PosTag.EC, PosTag.EF, PosTag.ETN, PosTag.ETM
        }
        
        self.DELIMITER_TAGS = {
            PosTag.SF, PosTag.SP, PosTag.SS,
            PosTag.SE, PosTag.SO, PosTag.SW
        }
        
        self.MODIFIER_TAGS = {
            'adverb': {PosTag.MAG, PosTag.MAJ},
            'adjective': {PosTag.MM},
            'determiner': {PosTag.MM}
        }

    def parse_morphemes(self, analyzed_str: str) -> List[Tuple[str, str]]:
        """Komoran 형태소 분석 결과를 파싱"""
        tokens = analyzed_str.split('/')
        pairs = []
        i = 0
        while i < len(tokens) - 1:
            word = tokens[i]
            tag = tokens[i + 1]
            
            if '+' in tag:
                tags = tag.split('+')
                pairs.append((word, tags[0]))
                for additional_tag in tags[1:]:
                    pairs.append(('', additional_tag))
            else:
                pairs.append((word, tag))
            i += 2
        return pairs

    def _combine_numbers(self, tokens: List[Tuple[str, str]]) -> List[Tuple[str, str]]:
        """숫자와 단위를 결합"""
        result = []
        number_chunk = []
        
        for word, tag in tokens:
            try:
                pos_tag = PosTag[tag]
                if pos_tag in self.NUMBER_TAGS or word in ['만', '천', '백', '십']:
                    number_chunk.append(word)
                else:
                    if number_chunk:
                        result.append((''.join(number_chunk), 'SN'))
                        number_chunk = []
                    result.append((word, tag))
            except KeyError:
                if number_chunk:
                    result.append((''.join(number_chunk), 'SN'))
                    number_chunk = []
                result.append((word, tag))
        
        if number_chunk:
            result.append((''.join(number_chunk), 'SN'))
            
        return result

    def _split_into_clauses(self, morphemes: List[Tuple[str, str]]) -> List[Clause]:
        """문장을 절로 분리"""
        clauses = []
        start_idx = 0
        
        for i, (word, tag) in enumerate(morphemes):
            try:
                pos_tag = PosTag[tag]
                if pos_tag in self.CLAUSE_ENDING_TAGS:
                    clauses.append(Clause(
                        morphemes[start_idx:i+1],
                        start_idx,
                        i,
                        True
                    ))
                    start_idx = i + 1
            except KeyError:
                continue
        
        if start_idx < len(morphemes):
            clauses.append(Clause(
                morphemes[start_idx:],
                start_idx,
                len(morphemes)-1,
                False
            ))
        
        return clauses

    def _calculate_confidence(self, result: SVOResult) -> float:
        """Calculate confidence score for extracted SVO"""
        score = 0.0
        components = 0
        
        if result.subject:
            score += 1.0
            components += 1
        if result.verb:
            score += 1.0
            components += 1
        if result.object:
            score += 1.0
            components += 1
            
        if result.modifiers:
            modifier_score = min(len(result.modifiers) * 0.1, 0.5)
            score += modifier_score
            components += 0.5
            
        return score / (components + 0.5) if components > 0 else 0.0

    def _extract_modifiers(self, morphemes: List[Tuple[str, str]]) -> Dict[str, List[str]]:
        """Extract modifiers from the clause"""
        modifiers = defaultdict(list)
        current_chunk = []
        
        for word, tag in morphemes:
            try:
                pos_tag = PosTag[tag]
                for mod_type, tags in self.MODIFIER_TAGS.items():
                    if pos_tag in tags:
                        if current_chunk:
                            modifiers[mod_type].append(''.join(current_chunk) + word)
                        else:
                            modifiers[mod_type].append(word)
                        current_chunk = []
                        break
            except KeyError:
                continue
                
        return dict(modifiers)

    def extract_svo_from_clause(self, morphemes: List[Tuple[str, str]]) -> SVOResult:
        """각 절에서 SVO 추출"""
        subject = ""
        object_word = ""
        verb = ""
        current_chunk = []
        has_verb = False
        
        modifiers = self._extract_modifiers(morphemes)
        
        for i, (word, tag) in enumerate(morphemes):
            try:
                pos_tag = PosTag[tag]
                
                if pos_tag in self.NOUN_TAGS or pos_tag in self.NUMBER_TAGS:
                    current_chunk.append(word)
                    continue
                
                if pos_tag in self.SUBJECT_PARTICLE_TAGS and current_chunk:
                    if not subject:
                        subject = ''.join(current_chunk)
                    current_chunk = []
                    continue
                
                if pos_tag in self.OBJECT_PARTICLE_TAGS and current_chunk:
                    if not object_word:
                        object_word = ''.join(current_chunk)
                    current_chunk = []
                    continue
                
                if (pos_tag in self.VERB_TAGS or 
                    (pos_tag == PosTag.NNG and i < len(morphemes)-1 and 
                     morphemes[i+1][1] == 'XSV')):
                    if not has_verb:
                        if current_chunk:
                            verb = ''.join(current_chunk) + word
                        else:
                            verb = word
                        has_verb = True
                    current_chunk = []
                    continue
                
                if pos_tag in self.DELIMITER_TAGS:
                    current_chunk = []
                
            except KeyError:
                continue
        
        result = SVOResult(
            subject=subject,
            verb=verb,
            object=object_word,
            modifiers=modifiers,
            confidence=0.0
        )
        result.confidence = self._calculate_confidence(result)
        
        return result

    def process_text(self, text: str) -> List[SVOResult]:
        """텍스트 처리의 메인 메서드"""
        morphemes = self.parse_morphemes(text)
        morphemes = self._combine_numbers(morphemes)
        clauses = self._split_into_clauses(morphemes)
        
        results = []
        for clause in clauses:
            result = self.extract_svo_from_clause(clause.morphemes)
            if result.subject or result.verb or result.object:
                results.append(result)
        
        return results

def main():
    from konlpy.tag import Komoran
    
    class MorphemeFormatter:
        def __init__(self):
            self.komoran = Komoran()
        
        def analyze_and_format(self, sentence):
            morphemes = self.komoran.pos(sentence)
            formatted = []
            for word, pos in morphemes:
                formatted.append(f"{word}/{pos}")
            return '/'.join(formatted)
    
    # 테스트 문장
    test_sentences = [
        "10년 논란 끝에 '광화문 현판'을 원점에서 재검토해 한글 현판으로 교체하자는 주장이 문화계 명사들이 포함된 자칭 '시민모임'에서 나왔다."
        ]
    
    formatter = MorphemeFormatter()
    extractor = KoreanSVOExtractor()
    
    # 각 문장 처리
    for sentence in test_sentences:
        print("\n원문:", sentence)
        
        try:
            komoran_result = formatter.analyze_and_format(sentence)
            print("형태소 분석:", komoran_result)
            
            svo_results = extractor.process_text(komoran_result)
            print("추출 결과:")
            
            for i, result in enumerate(svo_results, 1):
                if len(svo_results) > 1:
                    print(f"절 {i}:")
                print(result)
                
        except Exception as e:
            print(f"처리 중 오류 발생: {str(e)}")
            
        print("-" * 50)

if __name__ == "__main__":
    main()