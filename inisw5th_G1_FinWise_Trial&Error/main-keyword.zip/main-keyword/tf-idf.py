from sklearn.feature_extraction.text import TfidfVectorizer
from konlpy.tag import Okt
import numpy as np

def tokenize_korean(text):
    """
    Tokenize Korean text using Okt from Konlpy.
    Extracts nouns and meaningful tokens.
    """
    okt = Okt()
    tokens = okt.nouns(text)  # Extract nouns
    return tokens

def extract_main_keyword_tfidf(content):
    """
    Extract the main keyword from the given Korean article content using TF-IDF.
    
    Parameters:
    - content (str): The content of the article in Korean.
    
    Returns:
    - str: The main keyword.
    """
    if not content:
        return ""

    # Tokenize content
    tokenized_content = " ".join(tokenize_korean(content))

    # Compute TF-IDF
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([tokenized_content])
    feature_array = np.array(vectorizer.get_feature_names_out())
    tfidf_scores = tfidf_matrix.toarray().flatten()

    # Find the keyword with the highest TF-IDF score
    main_keyword_index = tfidf_scores.argmax()  # Index of the highest score
    main_keyword = feature_array[main_keyword_index]

    return main_keyword

# Example usage
article_content = """
미국 증시 3대 지수(S&P 500, 다우존스, 나스닥종합지수)가 모두 하락해 위험자산에 대한 선호가 줄어든 양상을 보이면서 비트코인 등 암호화폐(가상화폐)가 일제히 급락하고 있다. 10일 오전 8시 현재 글로벌 코인 시황 중계사이트인 코인마켓캡에서 비트코인은 24시간 전보다 3.52% 하락한 9만6578달러를 기록하고 있다. 이날 비트코인은 한때 9만4355달러까지 밀렸었다.

이는 약 7억5000만달러 규모의 파생상품이 청산됐기 때문이다.

오히려 비트코인은 비교적 선방한 편이다. 시총 2위 이더리움은 7.73%, 시총 4위 리플은 15.64%, 시총 5위 솔라나는 9.37% 각각 폭락하고 있다. 이로써 전일 시총 3위를 회복했던 리플은 다시 시총 4위로 떨어졌다.

다른 주요 알트코인도 일제히 폭락하고 있다. 시총 7위 도지코인은 11.63%, 시총 9위 카르다노는 15.27%, 시총 10위 트론은 18.43% 각각 폭락하고 있다.

약 1시간 전 이들은 20% 이상 폭락했었다. 지금은 낙폭은 줄이고 있는 중이다.

한편 코인마켓캡의 ‘가상자산 공포 및 탐욕 지수’에 따른 가상자산 심리 단계는 83점으로 ‘극도의 탐욕’ 단계를 나타냈다. 값이 제로(0)에 가까워지면 시장이 극도의 공포상태로 투자자들이 과매도를 하며, 100에 가까워지면 시장이 탐욕에 빠져 시장 조정 가능성이 있음을 뜻한다.
"""

main_keyword = extract_main_keyword_tfidf(article_content)
print("메인 키워드:", main_keyword)
