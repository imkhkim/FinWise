from gensim.summarization import keywords

def extract_keywords_textrank(content, num_keywords=10):
    """
    Extract main keywords from the given article content using TextRank.
    
    Parameters:
    - content (str): The content of the article.
    - num_keywords (int): Number of keywords to extract (default is 10).
    
    Returns:
    - list: List of extracted keywords.
    """
    if not content:
        return []

    # Extract keywords using gensim's TextRank implementation
    extracted_keywords = keywords(content, words=num_keywords, lemmatize=True, split=True)
    
    return extracted_keywords

# Example usage
article_content = """
Artificial intelligence (AI) is a rapidly evolving field that has captured the attention of researchers, 
businesses, and governments worldwide. From self-driving cars to natural language processing, AI is transforming 
industries and redefining what machines can do. However, it also raises ethical concerns and challenges regarding 
privacy, employment, and security. The global AI market is expected to grow significantly in the coming years, 
with investments pouring into research and development.
"""

main_keywords = extract_keywords_textrank(article_content, num_keywords=5)
print("Extracted Keywords:", main_keywords)
