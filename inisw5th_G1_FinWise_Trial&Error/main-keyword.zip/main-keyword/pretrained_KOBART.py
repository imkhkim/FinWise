from transformers import PreTrainedTokenizerFast, BartForConditionalGeneration

# Load Model and Tokenizer
tokenizer = PreTrainedTokenizerFast.from_pretrained("EbanLee/kobart-summary-v3")
model = BartForConditionalGeneration.from_pretrained("EbanLee/kobart-summary-v3")

# Encoding
input_text = "10년 논란 끝에 밑글씨까지 새기고 제작 완료를 눈앞에 둔 ‘광화문 현판’을 원점에서 재검토해 한글 현판으로 교체하자는 주장이 문화계 명사들이 포함된 자칭 ‘시민모임’에서 나왔다."
inputs = tokenizer(input_text, return_tensors="pt", padding="max_length", truncation=True, max_length=1026)

# Generate Summary Text Ids
summary_text_ids = model.generate(
    input_ids=inputs['input_ids'],
    attention_mask=inputs['attention_mask'],
    bos_token_id=model.config.bos_token_id,
    eos_token_id=model.config.eos_token_id,
    length_penalty=0.1,           # 1.0보다 작게 설정해서 짧은 문장 선호 => 0.3, 0.5, 07
    max_length=40,                # 1. 30, 2. 40
    min_length=10,                 # 1. 5, 10
    num_beams=5,                  # 1. 5, 
    repetition_penalty=2.0,       # 반복 패널티 증가
    no_repeat_ngram_size=10,       # ngram 크기 감소
    early_stopping=False,          # 문장 완성시 조기 종료
    temperature=1.3,              # 높은 temperature로 다양성 증가
    top_p=0.85,                  # nucleus sampling 활성화
    do_sample=True               # 샘플링 사용
)

# Decoding Text Ids
print(tokenizer.decode(summary_text_ids[0], skip_special_tokens=True))