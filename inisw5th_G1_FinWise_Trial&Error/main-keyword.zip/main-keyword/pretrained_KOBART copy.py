from transformers import PreTrainedTokenizerFast, BartForConditionalGeneration
import datetime
import os

def summarize_and_save(input_text, output_dir="summaries"):
    # Create output directory if it doesn't exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Load Model and Tokenizer
    tokenizer = PreTrainedTokenizerFast.from_pretrained("EbanLee/kobart-summary-v3")
    model = BartForConditionalGeneration.from_pretrained("EbanLee/kobart-summary-v3")

    # Encoding
    inputs = tokenizer(input_text, 
                      return_tensors="pt", 
                      padding="max_length", 
                      truncation=True, 
                      max_length=1026)

    # Generate Summary Text Ids
    summary_text_ids = model.generate(
        input_ids=inputs['input_ids'],
        attention_mask=inputs['attention_mask'],
        bos_token_id=model.config.bos_token_id,
        eos_token_id=model.config.eos_token_id,
        length_penalty=0.1,
        max_length=40,
        min_length=10,
        num_beams=6,
        repetition_penalty=2.0,
        no_repeat_ngram_size=10,
        early_stopping=False,
        temperature=1.3,
        top_p=0.85,
        do_sample=True
    )

    # Decode the summary
    summary = tokenizer.decode(summary_text_ids[0], skip_special_tokens=True)
    
    # Generate timestamp for unique filename
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"summary_{timestamp}.txt"
    filepath = os.path.join(output_dir, filename)
    
    # Save both input and summary to file
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(summary)
    
    print(f"Summary saved to: {filepath}")
    return summary

# Example usage
input_text = "10년 논란 끝에 밑글씨까지 새기고 제작 완료를 눈앞에 둔 '광화문 현판'을 원점에서 재검토해 한글 현판으로 교체하자는 주장이 문화계 명사들이 포함된 자칭 '시민모임'에서 나왔다."
summary = summarize_and_save(input_text)
print("\nGenerated Summary:")
print(summary)