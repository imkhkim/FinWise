import requests
from bs4 import BeautifulSoup
import json

# JSON 파일 경로
dictionary_file_path = "dictionary.json"

# JSON 파일에서 딕셔너리 데이터 로드
def load_dictionary(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

# JSON 파일에 딕셔너리 데이터 저장
def save_dictionary(file_path, dictionary):
    with open(file_path, 'w', encoding='utf-8') as file:
        json.dump(dictionary, file, ensure_ascii=False, indent=4)

# 한경 경제용어사전에서 정의 가져오기
def fetch_definition_hankyung(word):
    url = f"https://dic.hankyung.com/economy/list?word={word}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        try:
            # <div id="contents" class="contents"> 아래 첫 번째 <p> 태그 가져오기
            contents_div = soup.find("div", {"id": "contents", "class": "contents"})
            if contents_div:
                first_paragraph = contents_div.find("p")
                if first_paragraph:
                    return first_paragraph.text.strip()
                else:
                    print("<p> 태그를 찾을 수 없습니다.")
            else:
                print("<div id='contents'>를 찾을 수 없습니다.")
        except Exception as e:
            print(f"오류 발생: {e}")
            return None
    else:
        print(f"요청 실패: 상태 코드 {response.status_code}")
        return None

# 단어 정의 가져오기
def get_word_definition(word, dictionary_file_path):
    # JSON 파일에서 딕셔너리 로드
    dictionary = load_dictionary(dictionary_file_path)

    # JSON에서 단어 정의 확인
    if word in dictionary:
        print(f"{word}: {dictionary[word]}")
        return dictionary[word]

    # 딕셔너리에 정의가 없으면 한경 사전에서 검색
    print(f"'{word}'에 대한 정의를 검색 중...")
    definition = fetch_definition_hankyung(word)

    if definition:
        print(f"{word}: {definition}")
        # 정의를 딕셔너리에 추가 및 저장
        dictionary[word] = definition
        save_dictionary(dictionary_file_path, dictionary)
        print(f"정의가 '{dictionary_file_path}'사전에 추가되었습니다.")
        return definition
    else:
        print("Error... 정의를 찾을 수 없습니다.")
        return None

# 예시 단어
word = "도지코인"
definition = get_word_definition(word, dictionary_file_path)
if definition:
    print(f"최종 정의: {definition}")
else:
    print("Error... 정의를 찾을 수 없습니다.")
