console.log("JavaScript loaded!");
