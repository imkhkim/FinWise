# -*- coding: utf-8 -*-
## https://huggingface.co/EbanLee/kobart-summary-v3
import os
from transformers import PreTrainedTokenizerFast, BartForConditionalGeneration

def summarize_with_kobart(input_path, output_path):
    """KoBART를 이용해 입력 텍스트 요약"""
    # Load Model and Tokenizer
    tokenizer = PreTrainedTokenizerFast.from_pretrained("EbanLee/kobart-summary-v3")
    model = BartForConditionalGeneration.from_pretrained("EbanLee/kobart-summary-v3")

    # Load input text from a file
    with open(input_path, "r", encoding="utf-8") as file:
        input_text = file.read()

    # Encoding
    inputs = tokenizer(input_text, return_tensors="pt", padding="max_length", truncation=True, max_length=1026)

    # Generate Summary Text Ids
    summary_text_ids = model.generate(
        input_ids=inputs['input_ids'],
        attention_mask=inputs['attention_mask'],
        bos_token_id=model.config.bos_token_id,
        eos_token_id=model.config.eos_token_id,
        length_penalty=0.1,
        max_length=40,
        min_length=10,
        num_beams=6,
        repetition_penalty=2.0,
        no_repeat_ngram_size=10,
        early_stopping=False,
        temperature=1.3,
        top_p=0.85,
        do_sample=True
    )

    # Decoding Text Ids
    summary = tokenizer.decode(summary_text_ids[0], skip_special_tokens=True)

    # Save summary to a file
    with open(output_path, "w", encoding="utf-8") as file:
        file.write(summary)
    
    print(f"요약 결과가 {output_path}에 저장되었습니다.")
    return summary

if __name__ == "__main__":
    input_dir = "data"  # 원본 텍스트 파일 디렉터리
    output_dir = "summaries"  # 요약 결과 저장 디렉터리

    # 출력 디렉터리가 없으면 생성
    os.makedirs(output_dir, exist_ok=True)

    # 디렉터리에서 모든 .txt 파일 가져오기
    txt_files = [f for f in os.listdir(input_dir) if f.endswith('.txt')]

    for txt_file in txt_files:
        input_txt_path = os.path.join(input_dir, txt_file)
        summary_file_name = f"summary_{txt_file}"  # 요약 파일 이름 생성
        summary_path = os.path.join(output_dir, summary_file_name)

        # KoBART 요약
        summarize_with_kobart(input_txt_path, summary_path)
