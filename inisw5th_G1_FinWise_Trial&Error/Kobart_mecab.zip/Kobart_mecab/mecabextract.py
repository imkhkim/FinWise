import os
import json
import re
from konlpy.tag import Mecab

# Mecab 초기화
mecab = Mecab(dicpath=r"C:\mecab\mecab-ko-dic")  # dicpath는 Mecab 설치 경로에 맞게 수정

# 데이터 폴더 경로
data_folder = "summaries"  # 텍스트 파일들이 있는 폴더
results_folder = "results"  # 결과를 저장할 폴더
output_json = os.path.join(results_folder, "results.json")  # 결과를 저장할 JSON 파일 경로

# 결과 폴더 생성 (없으면 생성)
os.makedirs(results_folder, exist_ok=True)

# 결과를 저장할 리스트
results = []

# 폴더 내 .txt 파일 가져오기
txt_files = [f for f in os.listdir(data_folder) if f.endswith('.txt')]

# 문장 분리 함수 (구두점 기준으로 문장 분리)
def split_sentences(text):
    """구두점 기준으로 문장 분리"""
    return re.split(r'(?<=[.!?])\s+', text)

# 형태소 분석 및 명사, 동사 추출 함수
def extract_nouns_and_verbs(sentence):
    """주어진 문장에서 명사와 동사를 추출하여 반환"""
    morphemes = mecab.pos(sentence)
    
    # 명사와 동사 필터링
    nouns = [word for word, tag in morphemes if tag.startswith('NN') or tag in ['NP', 'NR']]  # 명사 확장
    verbs = [word for word, tag in morphemes if tag.startswith('VV') or tag.startswith('VA')]  # 동사 확장

    # 동사 하나만 선택 (최대 1개)
    selected_verbs = verbs[:1] if len(verbs) > 0 else [""]  # 동사는 최대 1개

    # 명사 2개 선택 (최소 2개, 부족하면 빈 값으로 채움)
    selected_nouns = (nouns + [""] * 2)[:2]  # 명사는 최대 2개, 부족하면 빈 값으로 채움

    return selected_verbs, selected_nouns

# 각 파일 처리
for file_name in txt_files:
    file_path = os.path.join(data_folder, file_name)
    print(f"\n처리 중: {file_name}")
    
    try:
        # 파일 읽기
        with open(file_path, "r", encoding="utf-8") as file:
            content = file.read()

        # 문장별로 분리
        sentences = split_sentences(content)

        # 각 문장 처리
        for sentence in sentences:
            selected_verbs, selected_nouns = extract_nouns_and_verbs(sentence)

            # 동사와 명사 조건이 만족되면 결과에 추가
            if selected_verbs[0] != "" and len(selected_nouns) == 2:
                # 원하는 만큼 동사-명사 쌍을 반복하여 추가
                repeat_count = 5  # 반복 횟수 (동사와 명사 쌍이 많이 나오도록 조정)
                for _ in range(repeat_count):  # 반복 횟수만큼 추가
                    results.append({
                        "verb": selected_verbs[0],  # 하나의 동사만 저장
                        "keywords": selected_nouns     # 두 개의 명사만 저장
                    })
    
    except Exception as e:
        print(f"파일 처리 중 오류 발생: {file_name} - {e}")

# JSON 파일로 저장
try:
    with open(output_json, "w", encoding="utf-8") as json_file:
        json.dump(results, json_file, ensure_ascii=False, indent=4)

    print(f"\n추출 결과가 {output_json} 파일에 저장되었습니다.")

except Exception as e:
    print(f"JSON 파일 저장 중 오류 발생: {e}")
